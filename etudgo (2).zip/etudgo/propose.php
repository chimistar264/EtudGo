<?php
session_start();
include 'includes/db.php';

// Vérifier si l'utilisateur est connecté et est un conducteur
if (!isset($_SESSION['user_id'])) {
    header('Location: login.php?redirect=propose');
    exit();
}

// Vérifier si l'utilisateur est un conducteur
$user_id = $_SESSION['user_id'];
$check_driver = $conn->prepare("SELECT id FROM drivers WHERE id = ?");
$check_driver->bind_param("i", $user_id);
$check_driver->execute();
$result = $check_driver->get_result();

if ($result->num_rows === 0) {
    header('Location: register_driver.php?message=devenez_conducteur');
    exit();
}
$check_driver->close();

$message = '';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Récupération et nettoyage des données du formulaire
    $conducteur_id = $_SESSION['user_id'];
    $depart = htmlspecialchars(trim($_POST['depart']));
    $destination = htmlspecialchars(trim($_POST['destination']));
    $date = $_POST['date'];
    $heure = $_POST['heure'];
    $nb_places = (int)$_POST['nb_places'];
    $prix = (float)$_POST['prix'];
    $description = htmlspecialchars(trim($_POST['description']));

    // Insertion dans la base de données
    $stmt = $conn->prepare("INSERT INTO trajets (driver_id, depart, destination, date_trajet, heure_trajet, nb_places, prix, description) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("issssids", $conducteur_id, $depart, $destination, $date, $heure, $nb_places, $prix, $description);

    if ($stmt->execute()) {
        $message = '<div class="success-message"><i class="fas fa-check-circle"></i> Trajet ajouté avec succès!</div>';
        // Redirection après 2 secondes
        header("refresh:2;url=mes-trajets.php");
    } else {
        $message = '<div class="error-message"><i class="fas fa-exclamation-circle"></i> Erreur: ' . $stmt->error . '</div>';
    }

    $stmt->close();
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Publier un trajet - EtudGo</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
  <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
  <link rel="stylesheet" href="assets/css/propose.css">
</head>
<body>
  <div class="form-container">
    <img src="assets/images/covoiturage-icon.png" alt="Covoiturage" class="logo" />
    
    <?php if (!empty($message)) echo $message; ?>
    
    <form method="post" action="">
      <h2><i class="fas fa-car-side"></i> Proposer un trajet</h2>

      <div class="input-group">
        <i class="fas fa-map-marker-alt"></i>
        <input type="text" name="depart" placeholder="Point de départ" required>
      </div>

      <div class="input-group">
        <i class="fas fa-location-dot"></i>
        <input type="text" name="destination" placeholder="Destination" required>
      </div>

      <div class="form-row">
        <div class="input-group">
          <i class="fas fa-calendar"></i>
          <input type="date" name="date" min="<?= date('Y-m-d') ?>" required>
        </div>
        <div class="input-group">
          <i class="fas fa-clock"></i>
          <input type="time" name="heure" required>
        </div>
      </div>

      <div class="form-row">
        <div class="input-group">
          <i class="fas fa-users"></i>
          <input type="number" name="nb_places" placeholder="Places" min="1" max="8" required>
        </div>
        <div class="input-group">
          <i class="fas fa-money-bill"></i>
          <input type="number" name="prix" placeholder="Prix MAD" min="0" step="0.01" required>
        </div>
      </div>

      <div class="input-group">
        <i class="fas fa-align-left"></i>
        <textarea name="description" placeholder="Informations complémentaires (facultatif)"></textarea>
      </div>

      <div class="buttons-group">
        <a href="home.php" class="btn-secondary"><i class="fas fa-arrow-left"></i> Annuler</a>
        <button type="submit" class="btn-primary"><i class="fas fa-paper-plane"></i> Publier</button>
      </div>
    </form>
  </div>
  
  <script>
  document.addEventListener('DOMContentLoaded', function() {
    // Validation du formulaire
    document.querySelector('form').addEventListener('submit', function(event) {
      const dateInput = document.querySelector('input[name="date"]');
      const today = new Date().toISOString().split('T')[0];
      
      if (dateInput.value < today) {
        alert('La date du trajet ne peut pas être dans le passé');
        event.preventDefault();
      }
    });
  });
  </script>
</body>
</html>