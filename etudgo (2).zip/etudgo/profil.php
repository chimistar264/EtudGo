<?php
session_start();
include 'includes/db.php';

//include 'includes/auth.php';

// Vérifier si l'utilisateur est connecté
//ensure_user_logged_in();

$page_title = "Mon profil - EtudGo";
$additional_css = ['assets/css/profil.css'];

// Récupérer les informations de l'utilisateur de manière sécurisée
$user_id = $_SESSION['user_id'];
$stmt = $conn->prepare("SELECT * FROM users WHERE id = ?");
$stmt->bind_param("i", $user_id);
$stmt->execute();
$user = $stmt->get_result()->fetch_assoc();
$stmt->close();

// Récupérer les informations spécifiques selon le rôle
$role_info = [];
if ($user['role'] === 'etudiant') {
    $stmt = $conn->prepare("SELECT * FROM students WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $role_info = $stmt->get_result()->fetch_assoc();
    $stmt->close();
} elseif ($user['role'] === 'conducteur') {
    $stmt = $conn->prepare("SELECT * FROM drivers WHERE id = ?");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $role_info = $stmt->get_result()->fetch_assoc();
    $stmt->close();
}

// Récupérer les trajets proposés si conducteur
$trajets = [];
if ($user['role'] === 'conducteur') {
    $stmt = $conn->prepare("
        SELECT t.*, COUNT(r.id) as reservations_count 
        FROM trajets t 
        LEFT JOIN reservations r ON t.id = r.trajet_id 
        WHERE t.driver_id = ? 
        GROUP BY t.id 
        ORDER BY t.date_trajet DESC
    ");
    $stmt->bind_param("i", $user_id);
    $stmt->execute();
    $result = $stmt->get_result();
    while ($row = $result->fetch_assoc()) {
        $trajets[] = $row;
    }
    $stmt->close();
}
?>
<!DOCTYPE html>
<div class="profile-container">
    <div class="profile-header">
        <div class="profile-avatar">
            <img src="<?= $user['photo'] ?? 'assets/images/default-avatar.png' ?>" alt="Photo de profil">
        </div>
        <div class="profile-info">
            <h1><?= htmlspecialchars($user['prenom'] . ' ' . $user['nom']) ?></h1>
            <p class="role-badge <?= $user['role'] ?>">
                <i class="fas <?= $user['role'] === 'conducteur' ? 'fa-car' : 'fa-graduation-cap' ?>"></i>
                <?= $user['role'] === 'conducteur' ? 'Conducteur' : 'Étudiant' ?>
            </p>
            <p><i class="fas fa-envelope"></i> <?= htmlspecialchars($user['email']) ?></p>
            <p><i class="fas fa-phone"></i>
<p><i class="fas fa-phone"></i> <?= htmlspecialchars($user['telephone']) ?></p>
            
            <?php if ($user['role'] === 'etudiant' && isset($role_info['cne'])): ?>
                <p><i class="fas fa-id-card"></i> CNE: <?= htmlspecialchars($role_info['cne']) ?></p>
                <p><i class="fas fa-graduation-cap"></i> Niveau: <?= htmlspecialchars($role_info['niveau_etude']) ?></p>
            <?php elseif ($user['role'] === 'conducteur' && isset($role_info['car_model'])): ?>
                <p><i class="fas fa-id-card"></i> N° Permis: <?= htmlspecialchars($role_info['license_number']) ?></p>
                <p><i class="fas fa-car"></i> Voiture: <?= htmlspecialchars($role_info['car_model']) ?></p>
                <p><i class="fas fa-fingerprint"></i> Immatriculation: <?= htmlspecialchars($role_info['immatriculation']) ?></p>
            <?php endif; ?>
        </div>
        <div class="profile-actions">
            <a href="edit-profile.php" class="btn-outline"><i class="fas fa-user-edit"></i> Modifier le profil</a>
            <a href="change-password.php" class="btn-outline"><i class="fas fa-lock"></i> Changer le mot de passe</a>
        </div>
    </div>
    
    <div class="profile-tabs">
        <ul class="tab-nav">
            <li class="active" data-tab="tab-overview"><i class="fas fa-home"></i> Vue d'ensemble</li>
            <?php if ($user['role'] === 'conducteur'): ?>
                <li data-tab="tab-trips"><i class="fas fa-route"></i> Mes trajets</li>
            <?php endif; ?>
            <li data-tab="tab-reservations"><i class="fas fa-ticket-alt"></i> Mes réservations</li>
            <li data-tab="tab-notifications"><i class="fas fa-bell"></i> Notifications</li>
        </ul>
        
        <div class="tab-content">
            <div id="tab-overview" class="tab-pane active">
                <div class="dashboard-stats">
                    <div class="stat-card">
                        <div class="stat-icon"><i class="fas fa-route"></i></div>
                        <div class="stat-content">
                            <h3>Trajets</h3>
                            <?php if ($user['role'] === 'conducteur'): ?>
                                <p><?= count($trajets) ?> proposés</p>
                            <?php else: ?>
                                <p>0 proposés</p>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <div class="stat-card">
                        <div class="stat-icon"><i class="fas fa-ticket-alt"></i></div>
                        <div class="stat-content">
                            <h3>Réservations</h3>
                            <?php
                            $stmt = $conn->prepare("SELECT COUNT(*) as count FROM reservations WHERE student_id = ?");
                            $stmt->bind_param("i", $user_id);
                            $stmt->execute();
                            $res_count = $stmt->get_result()->fetch_assoc()['count'];
                            $stmt->close();
                            ?>
                            <p><?= $res_count ?> effectuées</p>
                        </div>
                    </div>
                    
                    <?php if ($user['role'] === 'conducteur'): ?>
                        <div class="stat-card">
                            <div class="stat-icon"><i class="fas fa-star"></i></div>
                            <div class="stat-content">
                                <h3>Note</h3>
                                <?php
                                $stmt = $conn->prepare("SELECT AVG(rating) as avg_rating FROM ratings WHERE driver_id = ?");
                                $stmt->bind_param("i", $user_id);
                                $stmt->execute();
                                $avg_rating = $stmt->get_result()->fetch_assoc()['avg_rating'] ?? 0;
                                $stmt->close();
                                ?>
                                <p><?= number_format($avg_rating, 1) ?>/5</p>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                
                <div class="quick-actions">
                    <h2>Actions rapides</h2>
                    <div class="action-buttons">
                        <?php if ($user['role'] === 'conducteur'): ?>
                            <a href="propose.php" class="btn-primary"><i class="fas fa-plus-circle"></i> Proposer un trajet</a>
                        <?php endif; ?>
                        <a href="search.php" class="btn-secondary"><i class="fas fa-search"></i> Rechercher un trajet</a>
                    </div>
                </div>
                
                <?php if (!empty($trajets) && $user['role'] === 'conducteur'): ?>
                    <div class="recent-activities">
                        <h2>Trajets récents</h2>
                        <div class="activity-list">
                            <?php foreach (array_slice($trajets, 0, 3) as $trajet): ?>
                                <div class="activity-item">
                                    <div class="activity-icon"><i class="fas fa-car"></i></div>
                                    <div class="activity-content">
                                        <h3><?= htmlspecialchars($trajet['depart']) ?> → <?= htmlspecialchars($trajet['destination']) ?></h3>
                                        <p>Le <?= date('d/m/Y', strtotime($trajet['date_trajet'])) ?> à <?= $trajet['heure_trajet'] ?></p>
                                        <div class="activity-meta">
                                            <span><i class="fas fa-user-friends"></i> <?= $trajet['reservations_count'] ?>/<?= $trajet['nb_places'] ?> places</span>
                                            <span><i class="fas fa-money-bill-wave"></i> <?= $trajet['prix'] ?> MAD</span>
                                        </div>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
            
            <?php if ($user['role'] === 'conducteur'): ?>
                <div id="tab-trips" class="tab-pane">
                    <div class="action-header">
                        <h2>Mes trajets proposés</h2>
                        <a href="propose.php" class="btn-primary"><i class="fas fa-plus-circle"></i> Nouveau trajet</a>
                    </div>
                    
                    <?php if (empty($trajets)): ?>
                        <div class="empty-state">
                            <img src="assets/images/empty-trips.svg" alt="Aucun trajet">
                            <p>Vous n'avez pas encore proposé de trajet.</p>
                            <a href="propose.php" class="btn-primary">Proposer un trajet</a>
                        </div>
                    <?php else: ?>
                        <div class="trips-list">
                            <?php foreach ($trajets as $trajet): ?>
                                <div class="trip-card">
                                    <div class="trip-header">
                                        <h3><?= htmlspecialchars($trajet['depart']) ?> → <?= htmlspecialchars($trajet['destination']) ?></h3>
                                        <div class="trip-date">
                                            <i class="fas fa-calendar"></i> <?= date('d/m/Y', strtotime($trajet['date_trajet'])) ?>
                                            <i class="fas fa-clock"></i> <?= $trajet['heure_trajet'] ?>
                                        </div>
                                    </div>
                                    <div class="trip-content">
                                        <div class="trip-details">
                                            <p><i class="fas fa-user-friends"></i> <?= $trajet['reservations_count'] ?> / <?= $trajet['nb_places'] ?> places réservées</p>
                                            <p><i class="fas fa-money-bill-wave"></i> <?= $trajet['prix'] ?> MAD par personne</p>
                                        </div>
                                        <div class="trip-description">
                                            <?= nl2br(htmlspecialchars($trajet['description'])) ?>
                                        </div>
                                    </div>
                                    <div class="trip-actions">
                                        <a href="view-trip.php?id=<?= $trajet['id'] ?>" class="btn-outline"><i class="fas fa-eye"></i> Détails</a>
                                        <?php if (strtotime($trajet['date_trajet']) > time()): ?>
                                            <a href="edit-trip.php?id=<?= $trajet['id'] ?>" class="btn-outline"><i class="fas fa-edit"></i> Modifier</a>
                                            <a href="cancel-trip.php?id=<?= $trajet['id'] ?>" class="btn-outline btn-danger"><i class="fas fa-times-circle"></i> Annuler</a>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    <?php endif; ?>
                </div>
            <?php endif; ?>
            
            <div id="tab-reservations" class="tab-pane">
                <h2>Mes réservations</h2>
                
                <?php
                $stmt = $conn->prepare("
                    SELECT r.*, t.depart, t.destination, t.date_trajet, t.heure_trajet, t.prix,
                           u.nom as conducteur_nom, u.prenom as conducteur_prenom
                    FROM reservations r
                    JOIN trajets t ON r.trajet_id = t.id
                    JOIN users u ON t.driver_id = u.id
                    WHERE r.student_id = ?
                    ORDER BY t.date_trajet DESC
                ");
                $stmt->bind_param("i", $user_id);
                $stmt->execute();
                $reservations = $stmt->get_result();
                $stmt->close();
                
                if ($reservations->num_rows === 0):
                ?>
                    <div class="empty-state">
                        <img src="assets/images/empty-reservations.svg" alt="Aucune réservation">
                        <p>Vous n'avez pas encore de réservations.</p>
                        <a href="search.php" class="btn-primary">Rechercher un trajet</a>
                    </div>
                <?php else: ?>
                    <div class="reservations-list">
                        <?php while ($reservation = $reservations->fetch_assoc()): ?>
                            <div class="reservation-card">
                                <div class="reservation-header">
                                    <h3><?= htmlspecialchars($reservation['depart']) ?> → <?= htmlspecialchars($reservation['destination']) ?></h3>
                                    <div class="reservation-date">
                                        <i class="fas fa-calendar"></i> <?= date('d/m/Y', strtotime($reservation['date_trajet'])) ?>
                                        <i class="fas fa-clock"></i> <?= $reservation['heure_trajet'] ?>
                                    </div>
                                </div>
                                <div class="reservation-content">
                                    <p><i class="fas fa-user"></i> Conducteur: <?= htmlspecialchars($reservation['conducteur_prenom'] . ' ' . $reservation['conducteur_nom']) ?></p>
                                    <p><i class="fas fa-money-bill-wave"></i> Prix: <?= $reservation['prix'] ?> MAD</p>
                                </div>
                                <div class="reservation-actions">
                                    <a href="view-reservation.php?id=<?= $reservation['id'] ?>" class="btn-outline"><i class="fas fa-eye"></i> Détails</a>
                                    <?php if (strtotime($reservation['date_trajet']) > time()): ?>
                                        <a href="cancel-reservation.php?id=<?= $reservation['id'] ?>" class="btn-outline btn-danger"><i class="fas fa-times-circle"></i> Annuler</a>
                                    <?php endif; ?>
                                    <?php if (strtotime($reservation['date_trajet']) < time() && !isset($reservation['rating'])): ?>
                                        <a href="rate-driver.php?reservation_id=<?= $reservation['id'] ?>" class="btn-outline"><i class="fas fa-star"></i> Noter</a>
                                    <?php endif; ?>
                                </div>
                            </div>
                        <?php endwhile; ?>
                    </div>
                <?php endif; ?>
            </div>

<?php include 'includes/footer.php'; ?>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Gestion des onglets
    const tabNav = document.querySelectorAll('.tab-nav li');
    const tabContent = document.querySelectorAll('.tab-pane');
    
    tabNav.forEach(function(tab) {
        tab.addEventListener('click', function() {
            // Retirer la classe active de tous les onglets
            tabNav.forEach(item => item.classList.remove('active'));
            tabContent.forEach(item => item.classList.remove('active'));
            
            // Ajouter la classe active à l'onglet cliqué
            this.classList.add('active');
            const tabId = this.getAttribute('data-tab');
            document.getElementById(tabId).classList.add('active');
        });
    });
});
</script>