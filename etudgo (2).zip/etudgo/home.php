<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EtudGo - Covoiturage pour étudiants au Maroc</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/lucide@latest"></script>
</head>
<body>

    <!-- === HEADER === -->
    <header>
        <div class="container nav-container">
            <div class="logo">
                <i data-lucide="car"></i>
                <span>EtudGo</span>
            </div>
            <nav>
                <ul>
                    <?php if(isset($_SESSION['user_id'])): ?>
                        <li><a href="profil.php"><i data-lucide="user"></i> Mon profil</a></li>
                        <li><a href="logout.php" class="btn btn-tertiary"><i data-lucide="log-out"></i> Déconnexion</a></li>
                    <?php else: ?>
                        <li><a href="register.php" class="btn btn-secondary"><i data-lucide="user-plus"></i> S'inscrire</a></li>
                        <li><a href="login.php" class="btn btn-primary"><i data-lucide="log-in"></i> Connexion</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
        </div>
    </header>

    <!-- === HERO SECTION === -->
    <section class="hero">
        <div class="container hero-content">
            <div class="text">
                <h2>Le covoiturage pour les étudiants au Maroc</h2>
                <p>Trouvez facilement des covoiturages entre votre domicile et votre université. Économique, écologique et convivial !</p>
                <?php if(isset($_SESSION['user_id'])): ?>
                    <a href="search.php" class="btn btn-primary"><i data-lucide="search"></i> Rechercher un trajet</a>
                    <a href="propose.php" class="btn btn-secondary"><i data-lucide="plus-circle"></i> Proposer un trajet</a>
                <?php else: ?>
                    <a href="register.php" class="btn btn-primary"><i data-lucide="user-plus"></i> Rejoindre EtudGo</a>
                <?php endif; ?>
            </div>
            <div class="image">
                <img src="uploads\back2.png" alt="Étudiants près d'une voiture">
            </div>
        </div>
    </section>

    <!-- === SEARCH SECTION === -->
    <section class="container">
        <form action="search.php" method="GET" class="search-form">
            <div class="search-group">
                <span><i data-lucide="map-pin"></i></span>
                <input type="text" name="depart" class="search-input" placeholder="Point de départ">
            </div>

            <div class="search-group">
                <span><i data-lucide="map-pin"></i></span>
                <input type="text" name="destination" class="search-input" placeholder="Destination">
            </div>

            <div class="search-group">
                <span><i data-lucide="calendar"></i></span>
                <input type="date" name="date" class="search-input">
            </div>

            <button type="submit" class="btn btn-primary">
                <i data-lucide="search"></i> Rechercher
            </button>
        </form>
    </section>

    <!-- === STATS SECTION === -->
    <section class="container">
        <div class="stats">
            <div class="stat-item">
                <div class="stat-icon">
                    <i data-lucide="users"></i>
                </div>
                <div class="stat-number" id="users-count">0</div>
                <div class="stat-label">Étudiants inscrits</div>
            </div>
            <div class="stat-item">
                <div class="stat-icon">
                    <i data-lucide="map"></i>
                </div>
                <div class="stat-number" id="trips-count">0</div>
                <div class="stat-label">Trajets réalisés</div>
            </div>
            <div class="stat-item">
                <div class="stat-icon">
                    <i data-lucide="award"></i>
                </div>
                <div class="stat-number" id="universities-count">0</div>
                <div class="stat-label">Universités</div>
            </div>
        </div>
    </section>

    <!-- === WHY SECTION === -->
    <section class="why">
        <div class="container">
            <h2 class="section-title">Pourquoi choisir EtudGo ?</h2>
            <div class="cards">
                <div class="card">
                    <img src="uploads/WhatsApp Image 2025-04-19 at 20.20.10 (2).jpeg" alt="Étudiant">
                    <h4>Pour les étudiants</h4>
                    <p>Exclusivement réservé aux étudiants pour des trajets en toute confiance.</p>
                </div>
                
                <div class="card">
                    <img src="uploads/WhatsApp Image 2025-04-19 at 20.20.10 (1).jpeg" alt="Voiture">
                    <h4>Trajets vérifiés</h4>
                    <p>Conducteurs et véhicules vérifiés pour votre sécurité.</p>
                </div>

                <div class="card">
                    <img src="uploads/WhatsApp Image 2025-04-19 at 20.20.10.jpeg" alt="Recherche">
                    <h4>Recherche facile</h4>
                    <p>Trouvez rapidement le trajet qui vous convient.</p>
                </div>
            </div>
        </div>
    </section>

    <!-- === TESTIMONIALS SECTION === -->
    <section class="testimonials">
        <div class="container">
            <h2 class="section-title">Ce que disent nos utilisateurs</h2>
            <div class="testimonial-slider">
                <div class="testimonial">
                    <div class="testimonial-content">
                        <p>"Grâce à EtudGo, j'économise sur mes trajets vers la fac et j'ai rencontré des étudiants formidables !"</p>
                    </div>
                    <div class="testimonial-author">
                        <div class="avatar-placeholder"></div>
                        <div class="author-info">
                            <h4>Amine</h4>
                            <p>Étudiant à Casablanca</p>
                        </div>
                    </div>
                </div>
                <div class="testimonial">
                    <div class="testimonial-content">
                        <p>"Une application parfaite pour les étudiants ! Interface simple et communauté très sympathique."</p>
                    </div>
                    <div class="testimonial-author">
                        <div class="avatar-placeholder"></div>
                        <div class="author-info">
                            <h4>Salma</h4>
                            <p>Étudiante à Rabat</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- === HOW IT WORKS === -->
    <section class="how-it-works">
        <div class="container">
            <h2 class="section-title">Comment ça marche ?</h2>
            <div class="steps">
                <div class="step">
                    <div class="step-icon">
                        <i data-lucide="user-plus"></i>
                    </div>
                    <h3>Inscrivez-vous</h3>
                    <p>Créez votre compte étudiant ou conducteur en quelques clics</p>
                </div>
                <div class="step">
                    <div class="step-icon">
                        <i data-lucide="search"></i>
                    </div>
                    <h3>Recherchez</h3>
                    <p>Trouvez un trajet qui correspond à vos besoins</p>
                </div>
                <div class="step">
                    <div class="step-icon">
                        <i data-lucide="check-circle"></i>
                    </div>
                    <h3>Réservez</h3>
                    <p>Confirmez votre réservation et voyagez en toute sérénité</p>
                </div>
            </div>
        </div>
    </section>

    <!-- === CTA SECTION === -->
    <section class="cta">
        <div class="container">
            <h2>Prêt à rejoindre la communauté EtudGo ?</h2>
            <p>Inscrivez-vous dès maintenant et commencez à profiter de tous les avantages du covoiturage étudiant !</p>
            <a href="register.php" class="btn btn-primary btn-lg">S'inscrire gratuitement</a>
        </div>
    </section>

    <!-- === FOOTER === -->
    <footer>
        <div class="container footer-content">
            <p>&copy; 2025 EtudGo - Tous droits réservés.</p>
            <ul>
                <li><a href="#">À propos</a></li>
                <li><a href="#">FAQ</a></li>
                <li><a href="#">Mentions légales</a></li>
                <li><a href="#">Politique de confidentialité</a></li>
                <li><a href="#">Contact</a></li>
            </ul>
        </div>
    </footer>

    <script>
        // Initialisation des icônes Lucide
        lucide.createIcons();

        // Animation des compteurs
        function animateValue(id, start, end, duration) {
            const obj = document.getElementById(id);
            let startTimestamp = null;
            const step = (timestamp) => {
                if (!startTimestamp) startTimestamp = timestamp;
                const progress = Math.min((timestamp - startTimestamp) / duration, 1);
                obj.innerHTML = Math.floor(progress * (end - start) + start);
                if (progress < 1) {
                    window.requestAnimationFrame(step);
                }
            };
            window.requestAnimationFrame(step);
        }

        // Lancer l'animation quand la section est visible
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    animateValue("users-count", 0, 1250, 2000);
                    animateValue("trips-count", 0, 3760, 2000);
                    animateValue("universities-count", 0, 15, 2000);
                    observer.unobserve(entry.target);
                }
            });
        });

        observer.observe(document.querySelector('.stats'));
    </script>
</body>
</html>