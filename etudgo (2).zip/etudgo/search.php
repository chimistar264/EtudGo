<?php
// Inclusion des fichiers nécessaires
require_once 'includes/db.php';
require_once 'includes/function.php';
require_once 'includes/header.php';

// Initialisation des variables
$depart = isset($_GET['depart']) ? sanitize_input($_GET['depart']) : '';
$destination = isset($_GET['destination']) ? sanitize_input($_GET['destination']) : '';
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$resultats_par_page = 10;
$offset = ($page - 1) * $resultats_par_page;
$total_resultats = 0;

// Fonction pour nettoyer les entrées utilisateur
function sanitize_input($data) {
    global $conn;
    $data = trim($data);
    $data = stripslashes($data);
    $data = htmlspecialchars($data);
    return mysqli_real_escape_string($conn, $data);
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recherche de trajets</title>
    <link rel="stylesheet" href="assets/css/main.css">
    <link rel="stylesheet" href="assets/css/search.css">
</head>
<body>
    <div class="container">
        <section class="search-section">
            <h1>Rechercher un trajet</h1>
            
            <form method="get" class="search-form">
                <div class="form-group">
                    <label for="depart">Ville de départ</label>
                    <input type="text" id="depart" name="depart" placeholder="Ville de départ" value="<?php echo htmlspecialchars($depart); ?>">
                </div>
                
                <div class="form-group">
                    <label for="destination">Destination</label>
                    <input type="text" id="destination" name="destination" placeholder="Destination" value="<?php echo htmlspecialchars($destination); ?>">
                </div>
                
                <button type="submit" class="btn btn-primary">Rechercher</button>
            </form>
        </section>

        <?php if (isset($_GET['depart']) || isset($_GET['destination'])): ?>
            <section class="results-section">
                <h2>Résultats de recherche</h2>
                
                <?php
                // Requête pour compter le nombre total de résultats
                $count_query = "SELECT COUNT(*) as total FROM trajets WHERE 1=1";
                
                // Ajout des conditions de recherche si nécessaire
                if (!empty($depart)) {
                    $count_query .= " AND depart LIKE ?";
                    $depart_param = "%$depart%";
                }
                
                if (!empty($destination)) {
                    $count_query .= " AND destination LIKE ?";
                    $destination_param = "%$destination%";
                }
                
                // Préparation et exécution de la requête de comptage
                $stmt_count = mysqli_prepare($conn, $count_query);
                
                if (!empty($depart) && !empty($destination)) {
                    mysqli_stmt_bind_param($stmt_count, "ss", $depart_param, $destination_param);
                } elseif (!empty($depart)) {
                    mysqli_stmt_bind_param($stmt_count, "s", $depart_param);
                } elseif (!empty($destination)) {
                    mysqli_stmt_bind_param($stmt_count, "s", $destination_param);
                }
                
                mysqli_stmt_execute($stmt_count);
                $count_result = mysqli_stmt_get_result($stmt_count);
                $count_row = mysqli_fetch_assoc($count_result);
                $total_resultats = $count_row['total'];
                $total_pages = ceil($total_resultats / $resultats_par_page);
                
                // Requête pour récupérer les trajets
                $query = "SELECT * FROM trajets WHERE 1=1";
                
                // Ajout des conditions de recherche si nécessaire
                if (!empty($depart)) {
                    $query .= " AND depart LIKE ?";
                }
                
                if (!empty($destination)) {
                    $query .= " AND destination LIKE ?";
                }
                
                // Ajout de la pagination
                $query .= " ORDER BY date_trajet ASC LIMIT ? OFFSET ?";
                
                // Préparation de la requête
                $stmt = mysqli_prepare($conn, $query);
                
                // Bind des paramètres
                if (!empty($depart) && !empty($destination)) {
                    mysqli_stmt_bind_param($stmt, "ssii", $depart_param, $destination_param, $resultats_par_page, $offset);
                } elseif (!empty($depart)) {
                    mysqli_stmt_bind_param($stmt, "sii", $depart_param, $resultats_par_page, $offset);
                } elseif (!empty($destination)) {
                    mysqli_stmt_bind_param($stmt, "sii", $destination_param, $resultats_par_page, $offset);
                } else {
                    mysqli_stmt_bind_param($stmt, "ii", $resultats_par_page, $offset);
                }
                
                // Exécution de la requête
                mysqli_stmt_execute($stmt);
                $result = mysqli_stmt_get_result($stmt);
                
                // Affichage des résultats
                if (mysqli_num_rows($result) > 0) {
                    echo "<div class='results-count'>$total_resultats trajet(s) trouvé(s)</div>";
                    echo "<div class='results-list'>";
                    
                    while ($row = mysqli_fetch_assoc($result)) {
                        $date_formattee = date("d/m/Y", strtotime($row['date_trajet']));
                        ?>
                        <div class="trajet-card">
                            <div class="trajet-header">
                                <span class="trajet-departure"><?php echo htmlspecialchars($row['depart']); ?></span>
                                <span class="trajet-arrow">→</span>
                                <span class="trajet-destination"><?php echo htmlspecialchars($row['destination']); ?></span>
                            </div>
                            <div class="trajet-details">
                                <span class="trajet-date"><?php echo $date_formattee; ?></span>
                                <span class="trajet-time">à <?php echo htmlspecialchars($row['heure_trajet']); ?></span>
                            </div>
                            <div class="trajet-actions">
                                <a href="trajet.php?id=<?php echo (int)$row['id']; ?>" class="btn btn-view">Voir le détail</a>
                            </div>
                        </div>
                        <?php
                    }
                    
                    echo "</div>";
                    
                    // Affichage de la pagination
                    if ($total_pages > 1) {
                        echo "<div class='pagination'>";
                        for ($i = 1; $i <= $total_pages; $i++) {
                            $active_class = ($i == $page) ? 'active' : '';
                            echo "<a href='?depart=" . urlencode($depart) . "&destination=" . urlencode($destination) . "&page=$i' class='page-link $active_class'>$i</a>";
                        }
                        echo "</div>";
                    }
                } else {
                    echo "<div class='no-results'>Aucun trajet ne correspond à votre recherche.</div>";
                    echo "<div class='suggestions'>
                        <p>Suggestions :</p>
                        <ul>
                            <li>Vérifiez l'orthographe des villes saisies</li>
                            <li>Utilisez des termes plus généraux</li>
                            <li>Essayez une autre combinaison de villes</li>
                        </ul>
                    </div>";
                }
                ?>
            </section>
        <?php endif; ?>
    </div>

    <?php require_once 'includes/footer.php'; ?>

    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Mettre en surbrillance les résultats après la recherche
        const resultsList = document.querySelector('.results-list');
        if (resultsList) {
            setTimeout(() => {
                resultsList.classList.add('fade-in');
            }, 100);
        }
    });
    </script>
</body>
</html>