<?php
require_once 'includes/db.php';
require_once 'includes/function.php';
session_start();

// Redirection si non connecté
if (!isset($_SESSION['user_id'])) {
    $_SESSION['redirect_after_login'] = $_SERVER['REQUEST_URI'];
    header("Location: login.php?redirect=reservation");
    exit();
}

// Validation de l'ID du trajet
if (!isset($_GET['trajet_id']) || !filter_var($_GET['trajet_id'], FILTER_VALIDATE_INT)) {
   // set_alert('error', 'Identifiant de trajet invalide.');
    header('Location: index.php');
    exit();
}

$trajet_id = filter_var($_GET['trajet_id'], FILTER_SANITIZE_NUMBER_INT);
$etudiant_id = $_SESSION['user_id'];
$message = "";
$alert_type = "";

// Récupérer les informations du trajet
$sql = "SELECT t.*, u.nom, u.prenom, u.telephone, u.email, u.avatar, v.marque, v.modele, v.couleur, v.immatriculation 
        FROM trajets t
        LEFT JOIN utilisateurs u ON t.conducteur_id = u.id
        LEFT JOIN vehicules v ON t.vehicule_id = v.id
        WHERE t.id = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $trajet_id);
$stmt->execute();
$result = $stmt->get_result();
$trajet = $result->fetch_assoc();
$stmt->close();

if (!$trajet) {
    //set_alert('error', 'Ce trajet n\'existe pas ou a été supprimé.');
    header('Location: index.php');
    exit();
}

// Vérifier si l'étudiant a déjà réservé ce trajet
$sql_check = "SELECT id FROM reservations WHERE trajet_id = ? AND student_id = ? AND statut != 'annulée'";
$stmt_check = $conn->prepare($sql_check);
$stmt_check->bind_param("ii", $trajet_id, $etudiant_id);
$stmt_check->execute();
$result_check = $stmt_check->get_result();
$already_reserved = ($result_check->num_rows > 0);
$stmt_check->close();

// Traitement du formulaire de réservation
if ($_SERVER['REQUEST_METHOD'] === 'POST' && !$already_reserved) {
    // Vérifier le token CSRF
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $message = "Erreur de validation du formulaire. Veuillez réessayer.";
        $alert_type = "error";
    } else {
        $places_reservees = isset($_POST['places']) ? intval($_POST['places']) : 1;
        
        // Vérification des contraintes
        if ($places_reservees < 1) {
            $message = "Vous devez réserver au moins une place.";
            $alert_type = "error";
        } elseif ($places_reservees > $trajet['nb_places']) {
            $message = "Il n'y a pas assez de places disponibles.";
            $alert_type = "error";
        } else {
            // Démarrer une transaction
            $conn->begin_transaction();
            
            try {
                // Insérer la réservation
                $date_reservation = date('Y-m-d H:i:s');
                $statut = 'confirmée';
                
                $sql_insert = "INSERT INTO reservations (trajet_id, student_id, nb_places, date_reservation, statut) 
                               VALUES (?, ?, ?, ?, ?)";
                $stmt_insert = $conn->prepare($sql_insert);
                $stmt_insert->bind_param("iiiss", $trajet_id, $etudiant_id, $places_reservees, $date_reservation, $statut);
                $stmt_insert->execute();
                $reservation_id = $stmt_insert->insert_id;
                $stmt_insert->close();
                
                // Mettre à jour le nombre de places disponibles
                $sql_update = "UPDATE trajets SET nb_places = nb_places - ? WHERE id = ? AND nb_places >= ?";
                $stmt_update = $conn->prepare($sql_update);
                $stmt_update->bind_param("iii", $places_reservees, $trajet_id, $places_reservees);
                $stmt_update->execute();
                
                // Vérifier que la mise à jour a bien fonctionné
                if ($stmt_update->affected_rows == 0) {
                    throw new Exception("Les places ne sont plus disponibles.");
                }
                $stmt_update->close();
                
                // Envoyer notification au conducteur (en arrière-plan ou via une file d'attente)
                // send_notification($trajet['conducteur_id'], 'Nouvelle réservation', 'Un passager a réservé une place pour votre trajet.');
                
                // Confirmer la transaction
                $conn->commit();
                
                $message = "Votre réservation a été confirmée avec succès !";
                $alert_type = "success";
                $already_reserved = true;
                
                // Rafraîchir les données du trajet
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("i", $trajet_id);
                $stmt->execute();
                $result = $stmt->get_result();
                $trajet = $result->fetch_assoc();
                $stmt->close();
                
            } catch (Exception $e) {
                // Annuler la transaction en cas d'erreur
                $conn->rollback();
                $message = "Erreur lors de la réservation : " . $e->getMessage();
                $alert_type = "error";
            }
        }
    }
}

// Générer un token CSRF pour le formulaire
$csrf_token = bin2hex(random_bytes(32));
$_SESSION['csrf_token'] = $csrf_token;

// Formater la date et l'heure pour l'affichage
$date_formattee = date("d/m/Y", strtotime($trajet['date_trajet']));

// Inclure l'en-tête de la page
$page_title = "Réservation de trajet";
include 'includes/header.php';
?>

<div class="container">
    <div class="reservation-container">
        <div class="back-button">
            <a href="javascript:history.back()" class="btn btn-outline">
                <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M19 12H5M12 19l-7-7 7-7"></path>
                </svg>
                Retour aux résultats
            </a>
        </div>

        <div class="reservation-card">
            <h1 class="reservation-title">Réservation de trajet</h1>
            
            <?php if (!empty($message)): ?>
                <div class="alert alert-<?php echo $alert_type; ?>"><?php echo $message; ?></div>
            <?php endif; ?>
            
            <div class="trajet-details">
                <div class="trajet-header">
                    <div class="route-info">
                        <div class="trajet-route">
                            <span class="trajet-departure"><?php echo htmlspecialchars($trajet['depart']); ?></span>
                            <span class="trajet-arrow">→</span>
                            <span class="trajet-destination"><?php echo htmlspecialchars($trajet['destination']); ?></span>
                        </div>
                        <div class="trajet-datetime">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect>
                                <line x1="16" y1="2" x2="16" y2="6"></line>
                                <line x1="8" y1="2" x2="8" y2="6"></line>
                                <line x1="3" y1="10" x2="21" y2="10"></line>
                            </svg>
                            <span><?php echo $date_formattee; ?></span>
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <circle cx="12" cy="12" r="10"></circle>
                                <polyline points="12 6 12 12 16 14"></polyline>
                            </svg>
                            <span><?php echo htmlspecialchars($trajet['heure_trajet']); ?></span>
                        </div>
                    </div>
                    <div class="price-badge">
                        <span class="price"><?php echo htmlspecialchars($trajet['prix']); ?> MAD</span>
                        <span class="price-per-person">par personne</span>
                    </div>
                </div>
                
                <div class="driver-info">
                    <div class="driver-profile">
                        <?php if (!empty($trajet['avatar'])): ?>
                            <img src="assets/img/avatars/<?php echo htmlspecialchars($trajet['avatar']); ?>" alt="Photo de profil" class="driver-avatar">
                        <?php else: ?>
                            <div class="driver-avatar driver-avatar-placeholder">
                                <?php echo strtoupper(substr($trajet['prenom'], 0, 1) . substr($trajet['nom'], 0, 1)); ?>
                            </div>
                        <?php endif; ?>
                        <div class="driver-details">
                            <h3 class="driver-name"><?php echo htmlspecialchars($trajet['prenom'] . ' ' . substr($trajet['nom'], 0, 1) . '.'); ?></h3>
                            <?php if (isset($trajet['note_moyenne'])): ?>
                                <div class="driver-rating">
                                    <?php for ($i = 1; $i <= 5; $i++): ?>
                                        <?php if ($i <= round($trajet['note_moyenne'])): ?>
                                            <span class="star filled">★</span>
                                        <?php else: ?>
                                            <span class="star">☆</span>
                                        <?php endif; ?>
                                    <?php endfor; ?>
                                    <span class="rating-count">(<?php echo isset($trajet['nb_avis']) ? $trajet['nb_avis'] : '0'; ?>)</span>
                                </div>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <?php if (!empty($trajet['vehicule_id'])): ?>
                        <div class="vehicle-info">
                            <div class="vehicle-icon">
                                <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                    <rect x="1" y="6" width="22" height="12" rx="2" ry="2"></rect>
                                    <circle cx="7" cy="18" r="2"></circle>
                                    <circle cx="17" cy="18" r="2"></circle>
                                </svg>
                            </div>
                            <div class="vehicle-details">
                                <span class="vehicle-model"><?php echo htmlspecialchars($trajet['marque'] . ' ' . $trajet['modele']); ?></span>
                                <span class="vehicle-color"><?php echo htmlspecialchars($trajet['couleur']); ?></span>
                            </div>
                        </div>
                    <?php endif; ?>
                </div>
                
                <div class="seats-info">
                    <div class="seats-icon">
                        <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M16 4a4 4 0 1 0 0 8 4 4 0 0 0 0-8z"></path>
                            <path d="M15.2 14h1.6c2.4 0 4.2 1.3 4.2 3v3H11v-3c0-1.7 1.8-3 4.2-3z"></path>
                            <path d="M7 2a4 4 0 1 0 0 8 4 4 0 0 0 0-8z"></path>
                            <path d="M6.2 12h1.6c2.4 0 4.2 1.3 4.2 3v3H2v-3c0-1.7 1.8-3 4.2-3z"></path>
                        </svg>
                    </div>
                    <div class="seats-details">
                        <span class="seats-available"><?php echo htmlspecialchars($trajet['nb_places']); ?> place<?php echo $trajet['nb_places'] > 1 ? 's' : ''; ?> disponible<?php echo $trajet['nb_places'] > 1 ? 's' : ''; ?></span>
                    </div>
                </div>
                
                <?php if (!empty($trajet['commentaire'])): ?>
                    <div class="trajet-notes">
                        <div class="notes-icon">
                            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path>
                            </svg>
                        </div>
                        <div class="notes-content">
                            <p><?php echo nl2br(htmlspecialchars($trajet['commentaire'])); ?></p>
                        </div>
                    </div>
                <?php endif; ?>
            </div>
            
            <div class="reservation-form-section">
                <?php if ($trajet['nb_places'] > 0 && !$already_reserved): ?>
                    <form method="POST" class="reservation-form">
                        <input type="hidden" name="csrf_token" value="<?php echo $csrf_token; ?>">
                        
                        <div class="form-group">
                            <label for="places">Nombre de places à réserver :</label>
                            <div class="quantity-selector">
                                <button type="button" class="quantity-btn minus-btn" onclick="decrementPlaces()">-</button>
                                <input type="number" name="places" id="places" min="1" max="<?php echo $trajet['nb_places']; ?>" value="1" required>
                                <button type="button" class="quantity-btn plus-btn" onclick="incrementPlaces()">+</button>
                            </div>
                        </div>
                        
                        <div class="reservation-summary">
                            <div class="summary-row">
                                <span>Prix par place</span>
                                <span><?php echo htmlspecialchars($trajet['prix']); ?> MAD</span>
                            </div>
                            <div class="summary-row">
                                <span>Nombre de places</span>
                                <span id="nb-places-display">1</span>
                            </div>
                            <div class="summary-row total">
                                <span>Total</span>
                                <span id="total-price"><?php echo htmlspecialchars($trajet['prix']); ?> MAD</span>
                            </div>
                        </div>
                        
                        <button type="submit" class="btn btn-primary btn-reserve">
                            <svg xmlns="http://www.w3.org/2000/svg" width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                                <path d="M5 12h14M12 5l7 7-7 7"></path>
                            </svg>
                            Confirmer la réservation
                        </button>
                    </form>
                <?php elseif ($already_reserved): ?>
                    <div class="reservation-status reserved">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
                            <polyline points="22 4 12 14.01 9 11.01"></polyline>
                        </svg>
                        <p>Vous avez déjà réservé ce trajet</p>
                        <a href="mes-reservations.php" class="btn btn-secondary">Voir mes réservations</a>
                    </div>
                <?php else: ?>
                    <div class="reservation-status no-seats">
                        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                            <circle cx="12" cy="12" r="10"></circle>
                            <line x1="8" y1="12" x2="16" y2="12"></line>
                        </svg>
                        <p>Ce trajet est complet</p>
                        <a href="recherche.php" class="btn btn-secondary">Trouver un autre trajet</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
    // Initialiser l'affichage du prix total
    updateTotalPrice();
});

function decrementPlaces() {
    const input = document.getElementById('places');
    const currentValue = parseInt(input.value);
    if (currentValue > 1) {
        input.value = currentValue - 1;
        updateTotalPrice();
    }
}

function incrementPlaces() {
    const input = document.getElementById('places');
    const currentValue = parseInt(input.value);
    const maxValue = parseInt(input.getAttribute('max'));
    if (currentValue < maxValue) {
        input.value = currentValue + 1;
        updateTotalPrice();
    }
}

function updateTotalPrice() {
    const prixUnitaire = <?php echo floatval($trajet['prix']); ?>;
    const nbPlaces = parseInt(document.getElementById('places').value);
    const totalPrice = prixUnitaire * nbPlaces;
    
    document.getElementById('nb-places-display').textContent = nbPlaces;
    document.getElementById('total-price').textContent = totalPrice.toFixed(2) + ' MAD';
}
</script>

<?php include 'includes/footer.php'; ?>