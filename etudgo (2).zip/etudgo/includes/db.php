<?php
$host = "localhost";  // Laisse "localhost" si tu es en local avec XAMPP
$user = "root";       // Par défaut, XAMPP utilise "root"
$password = "";       // Mets "" (vide) si tu n’as pas défini de mot de passe pour root
$database = "etudgo_db"; // Vérifie que c'est bien le nom de ta base de données

$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    die("Échec de la connexion : " . $conn->connect_error);
}

// Option pour forcer MySQL à afficher les erreurs SQL
mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);
?>