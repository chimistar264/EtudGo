<?php
// includes/header.php
session_start();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $page_title ?? 'EtudGo - Covoiturage pour étudiants' ?></title>
    
    <!-- Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">
    
    <!-- Font Awesome -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
    
    <!-- Main CSS -->
    <link rel="stylesheet" href="assets/css/main.css">
    
    <!-- Page specific CSS -->
    <?php if(isset($additional_css)): ?>
        <?php foreach($additional_css as $css): ?>
            <link rel="stylesheet" href="<?= $css ?>">
        <?php endforeach; ?>
    <?php endif; ?>
</head>
<body>
    <header class="main-header">
        <div class="container">
            <a href="index.php" class="logo">
                <img src="assets/images/logo.svg" alt="EtudGo">
                <span>EtudGo</span>
            </a>
            
            <nav class="main-nav">
                <ul>
                    <li><a href="home.php">Accueil</a></li>
                    <li><a href="search.php">Rechercher</a></li>
                    <?php if(isset($_SESSION['user_id'])): ?>
                        <li><a href="propose.php">Proposer un trajet</a></li>
                        <li><a href="reservations.php">Mes réservations</a></li>
                        <li><a href="profil.php">Mon profil</a></li>
                        <li><a href="logout.php" class="btn-outline">Déconnexion</a></li>
                    <?php else: ?>
                        <li><a href="login.php" class="btn-outline">Connexion</a></li>
                        <li><a href="register.php" class="btn-primary">Inscription</a></li>
                    <?php endif; ?>
                </ul>
            </nav>
            
            <button class="mobile-menu-toggle">
                <i class="fas fa-bars"></i>
            </button>
        </div>
    </header>
    
    <main>
        <div class="container">
            <!-- Flash messages -->
            <?php if(isset($_SESSION['flash_message'])): ?>
                <div class="alert alert-<?= $_SESSION['flash_type'] ?? 'info' ?>">
                    <?= $_SESSION['flash_message'] ?>
                    <button class="close-alert"><i class="fas fa-times"></i></button>
                </div>
                <?php unset($_SESSION['flash_message'], $_SESSION['flash_type']); ?>
            <?php endif; ?>