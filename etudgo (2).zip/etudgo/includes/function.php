<?php
// includes/upload.php

/**
 * Gestion sécurisée de l'upload des images
 * @param array $file Fichier à uploader ($_FILES['field'])
 * @param string $directory Dossier de destination
 * @param array $allowedTypes Types MIME autorisés
 * @param int $maxSize Taille maximale en octets
 * @return array Statut et chemin du fichier
 */
function secure_upload($file, $directory = "uploads/", $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'], $maxSize = 2097152) {
    // Vérifier si le dossier existe, sinon le créer
    if (!is_dir($directory)) {
        if (!mkdir($directory, 0755, true)) {
            return ['status' => false, 'message' => 'Impossible de créer le dossier de destination.'];
        }
    }
    
    // Vérifier si le fichier a été correctement uploadé
    if (!isset($file) || $file['error'] !== 0) {
        return ['status' => false, 'message' => 'Erreur lors de l\'upload du fichier.'];
    }
    
    // Vérifier le type MIME
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $fileType = $finfo->file($file['tmp_name']);
    
    if (!in_array($fileType, $allowedTypes)) {
        return ['status' => false, 'message' => 'Type de fichier non autorisé.'];
    }
    
    // Vérifier la taille
    if ($file['size'] > $maxSize) {
        return ['status' => false, 'message' => 'Le fichier est trop volumineux.'];
    }
    
    // Générer un nom de fichier unique
    $extension = pathinfo($file['name'], PATHINFO_EXTENSION);
    $newFilename = uniqid() . '_' . bin2hex(random_bytes(8)) . '.' . $extension;
    $destination = $directory . $newFilename;
    
    // Déplacer le fichier
    if (!move_uploaded_file($file['tmp_name'], $destination)) {
        return ['status' => false, 'message' => 'Erreur lors du déplacement du fichier.'];
    }
    
    return ['status' => true, 'path' => $destination];
}