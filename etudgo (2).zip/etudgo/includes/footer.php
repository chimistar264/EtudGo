<?php
// includes/footer.php
?>
        </div><!-- /.container -->
    </main>
    
    <footer class="main-footer">
        <div class="container">
            <div class="footer-content">
                <div class="footer-brand">
                    <img src="assets/images/logo.svg" alt="EtudGo">
                    <p>Covoiturage pour étudiants</p>
                </div>
                
                <div class="footer-links">
                    <div class="footer-column">
                        <h3>À propos</h3>
                        <ul>
                            <li><a href="about.php">Qui sommes-nous</a></li>
                            <li><a href="contact.php">Contact</a></li>
                        </ul>
                    </div>
                    
                    <div class="footer-column">
                        <h3>Légal</h3>
                        <ul>
                            <li><a href="terms.php">Conditions d'utilisation</a></li>
                            <li><a href="privacy.php">Politique de confidentialité</a></li>
                        </ul>
                    </div>
                </div>
            </div>
            
            <div class="footer-bottom">
                <p>&copy; <?= date('Y') ?> EtudGo. Tous droits réservés.</p>
                <div class="social-links">
                    <a href="#"><i class="fab fa-facebook-f"></i></a>
                    <a href="#"><i class="fab fa-twitter"></i></a>
                    <a href="#"><i class="fab fa-instagram"></i></a>
                </div>
            </div>
        </div>
    </footer>
    
    <script src="assets/js/main.js"></script>
    <?php if(isset($additional_js)): ?>
        <?php foreach($additional_js as $js): ?>
            <script src="<?= $js ?>"></script>
        <?php endforeach; ?>
    <?php endif; ?>
</body>
</html>