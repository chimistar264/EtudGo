<?php
include 'includes/db.php';
error_reporting(E_ALL);
ini_set('display_errors', 1);

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nom = trim($_POST['nom']);
    $prenom = trim($_POST['prenom']);
    $tel = trim($_POST['telephone']);
    $email = trim($_POST['email']);
    $password = $_POST['mot_de_passe'];
    $role = $_POST['role'];

    // Vérifier si l'email est déjà utilisé
    $stmtCheck = $conn->prepare("SELECT id FROM users WHERE email = ?");
    $stmtCheck->bind_param("s", $email);
    $stmtCheck->execute();
    $stmtCheck->store_result();

    if ($stmtCheck->num_rows > 0) {
        die("Cet email est déjà utilisé. <a href='register.php'>Réessayer</a>");
    }
    $stmtCheck->close();

    // Hasher le mot de passe
    $hashedPassword = password_hash($password, PASSWORD_DEFAULT);

    // Gestion de l'upload des photos
    function uploadImage($file, $dossier = "uploads/") {
        if (!is_dir($dossier)) mkdir($dossier, 0777, true);
        if (isset($file) && $file['error'] === 0) {
            $nomFichier = uniqid() . "_" . basename($file["name"]);
            $cheminComplet = $dossier . $nomFichier;
            if (move_uploaded_file($file["tmp_name"], $cheminComplet)) {
                return $cheminComplet;
            }
        }
        return 'uploads/default.png'; // Valeur par défaut
    }

    $photo_path = uploadImage($_FILES['photo']);
    $photo_vehicule_path = ($role == 'conducteur') ? uploadImage($_FILES['photo_vehicule']) : null;

    // Insertion dans la table users
    $stmt = $conn->prepare("INSERT INTO users (nom, prenom, telephone, email, mot_de_passe, role) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssss", $nom, $prenom, $tel, $email, $hashedPassword, $role);
    
    if ($stmt->execute()) {
        $user_id = $conn->insert_id;
        
        // Insertion dans la table correspondante
        if ($role == 'etudiant') {
            $cne = $_POST['cne'];
            $niveau = $_POST['niveau'];
            $stmt2 = $conn->prepare("INSERT INTO students (id, cne, niveau_etude) VALUES (?, ?, ?)");
            $stmt2->bind_param("iss", $user_id, $cne, $niveau);
            $stmt2->execute();
        } elseif ($role == 'conducteur') {
            $num = $_POST['num'];
            $mdl_voiture = $_POST['mdl_voiture'];
            $immat = $_POST['immatriculation'];
            $seats = $_POST['nombre_sieges'];

            $stmt3 = $conn->prepare("INSERT INTO drivers (id, license_number, car_model, immatriculation, seats_available, photo_vehicule) VALUES (?, ?, ?, ?, ?, ?)");
            $stmt3->bind_param("isssis", $user_id, $num, $mdl_voiture, $immat, $seats, $photo_vehicule_path);
            $stmt3->execute();
        }
        // Redirection après l'inscription
        header("Location: login.php");
        exit();
    } else {
        echo "Erreur lors de l'inscription.";
    }
    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inscription - EtudGo</title>
    <link rel="stylesheet" href="assets/css/register.css">
    <link rel="stylesheet" href="assets/css/style.css">
    
</head>
<body>
    <div class="form-container">
        <h1>Rejoignez notre communauté</h1>

        <div class="role-toggle">
            <button type="button" id="btn-etudiant" class="active">Étudiant</button>
            <button type="button" id="btn-conducteur">Conducteur</button>
        </div>

        <form method="post" enctype="multipart/form-data">
            <div class="name-container">
                <input type="text" name="nom" placeholder="Nom" required>
                <input type="text" name="prenom" placeholder="Prénom" required>
            </div>

            <input type="text" name="telephone" placeholder="Téléphone" required>
            <input type="email" name="email" placeholder="Email" required>
            <input type="password" name="mot_de_passe" placeholder="Mot de passe" required>

            <!-- Champs spécifiques à l'étudiant -->
            <div id="student-fields">
                <input type="text" name="cne" placeholder="CNE">
                <input type="text" name="niveau" placeholder="Niveau d'étude">
            </div>

            <!-- Champs spécifiques au conducteur -->
            <div id="driver-fields" style="display:none;">
                <input type="text" name="num" placeholder="Numéro de permis">
                <input type="text" name="mdl_voiture" placeholder="Modèle de voiture">
                <input type="text" name="immatriculation" placeholder="Immatriculation">
                <input type="number" name="nombre_sieges" placeholder="Nombre de sièges">
                <label for="photo">Photo du conducteur :</label>
                <input type="file" name="photo" accept="image/*">
                <label for="photo_vehicule">Photo du véhicule :</label>
                <input type="file" name="photo_vehicule" accept="image/*">
            </div>

            <input type="hidden" name="role" id="role" value="etudiant">
            <button type="submit">S'inscrire</button>
            <p>Déja inscrit ? <a href="login.php">Se connecter</a></p>
        </form>
    </div>

    <script>
        document.getElementById('btn-etudiant').addEventListener('click', function() {
            document.getElementById('student-fields').style.display = 'block';
            document.getElementById('driver-fields').style.display = 'none';
            document.getElementById('role').value = 'etudiant';
            this.classList.add('active');
            document.getElementById('btn-conducteur').classList.remove('active');
        });

        document.getElementById('btn-conducteur').addEventListener('click', function() {
            document.getElementById('student-fields').style.display = 'none';
            document.getElementById('driver-fields').style.display = 'block';
            document.getElementById('role').value = 'conducteur';
            this.classList.add('active');
            document.getElementById('btn-etudiant').classList.remove('active');
        });
    </script>
</body>
</html>
<?php include 'includes/footer.php'; ?>
<script src="https://unpkg.com/lucide@latest"></script>
<script>
    // Initialisation de Lucide
    window.addEventListener('DOMContentLoaded', () => {
        lucide.createIcons();
    });
</script>