<?php
session_start();
require_once 'includes/db.php';

// Validation de l'ID du trajet
if (!isset($_GET['id']) || !filter_var($_GET['id'], FILTER_VALIDATE_INT)) {
    header('Location: index.php?error=trajet_invalide');
    exit();
}

$trajet_id = filter_var($_GET['id'], FILTER_SANITIZE_NUMBER_INT);

// Récupération des détails du trajet avec tous les liens vers les tables nécessaires
$sql = "SELECT t.*, 
               u.nom, u.prenom, u.telephone,
               d.car_model, d.immatriculation, d.photo as photo_vehicule,
               (SELECT COUNT(*) FROM reservations WHERE trajet_id = t.id AND statut != 'annulée') as places_reservees,
               (SELECT AVG(r.rating) FROM ratings r WHERE r.driver_id = t.driver_id) as note_moyenne,
               (SELECT COUNT(r.id) FROM ratings r WHERE r.driver_id = t.driver_id) as nb_avis
        FROM trajets t
        JOIN users u ON t.driver_id = u.id
        JOIN drivers d ON t.driver_id = d.id
        WHERE t.id = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $trajet_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows === 0) {
    header('Location: index.php?error=trajet_inexistant');
    exit();
}

$trajet = $result->fetch_assoc();
$stmt->close();

// Calculer les places restantes
$places_disponibles = $trajet['nb_places'] - ($trajet['places_reservees'] ?? 0);

// Vérifier si l'utilisateur a déjà réservé ce trajet
$already_reserved = false;
if (isset($_SESSION['user_id'])) {
    $user_id = $_SESSION['user_id'];
    
    // Vérifier d'abord si l'utilisateur est un étudiant
    $check_student = $conn->prepare("SELECT id FROM students WHERE id = ?");
    $check_student->bind_param("i", $user_id);
    $check_student->execute();
    $student_result = $check_student->get_result();
    $is_student = ($student_result->num_rows > 0);
    $check_student->close();
    
    if ($is_student) {
        $check_reservation = $conn->prepare("SELECT id FROM reservations WHERE trajet_id = ? AND student_id = ? AND statut != 'annulée'");
        $check_reservation->bind_param("ii", $trajet_id, $user_id);
        $check_reservation->execute();
        $already_reserved = ($check_reservation->get_result()->num_rows > 0);
        $check_reservation->close();
    }
}

// Formatage de la date
$date_formattee = date("d/m/Y", strtotime($trajet['date_trajet']));
$today = date("Y-m-d");
$trajet_passed = ($trajet['date_trajet'] < $today);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Détails du trajet - EtudGo</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;600&display=swap" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css" rel="stylesheet">
    <link rel="stylesheet" href="assets/css/trajet.css">
</head>
<body>
    <div class="container">
        <div class="back-button">
            <a href="javascript:history.back()" class="btn-outline">
                <i class="fas fa-arrow-left"></i> Retour
            </a>
        </div>

        <div class="trajet-card">
            <!-- En-tête du trajet -->
            <div class="trajet-header">
                <div>
                    <div class="trajet-route">
                        <span><?= htmlspecialchars($trajet['depart']) ?></span>
                        <i class="fas fa-arrow-right" style="margin: 0 10px;"></i>
                        <span><?= htmlspecialchars($trajet['destination']) ?></span>
                    </div>
                    <div class="trajet-date">
                        <i class="fas fa-calendar"></i> <?= $date_formattee ?>
                        <i class="fas fa-clock" style="margin-left: 10px;"></i> <?= htmlspecialchars($trajet['heure_trajet']) ?>
                    </div>
                </div>
                <div class="trajet-prix">
                    <?= htmlspecialchars($trajet['prix']) ?> MAD
                </div>
            </div>

            <!-- Informations du conducteur -->
            <div class="driver-section">
                <div class="driver-info">
                    <div class="driver-initials">
                        <?= strtoupper(substr($trajet['prenom'], 0, 1) . substr($trajet['nom'], 0, 1)) ?>
                    </div>
                    <div>
                        <h3 style="margin: 0;"><?= htmlspecialchars($trajet['prenom'] . ' ' . substr($trajet['nom'], 0, 1) . '.') ?></h3>
                        <div class="rating">
                            <?php
                            $note = round($trajet['note_moyenne'] ?? 0);
                            for ($i = 1; $i <= 5; $i++) {
                                echo ($i <= $note) ? '<span class="star full">★</span>' : '<span class="star">☆</span>';
                            }
                            ?>
                            <span style="margin-left: 5px; color: #666; font-size: 14px;">(<?= $trajet['nb_avis'] ?? '0' ?>)</span>
                        </div>
                    </div>
                </div>
                <div class="car-info">
                    <i class="fas fa-car" style="margin-right: 10px; font-size: 18px;"></i>
                    <div>
                        <div><?= htmlspecialchars($trajet['car_model']) ?></div>
                        <div style="color: #666; font-size: 14px;"><?= htmlspecialchars($trajet['immatriculation']) ?></div>
                    </div>
                </div>
            </div>

            <!-- Détails du trajet -->
            <div class="details-section">
                <div class="detail">
                    <i class="fas fa-users"></i>
                    <div>
                        <label>Places disponibles</label>
                        <div><?= $places_disponibles ?> sur <?= htmlspecialchars($trajet['nb_places']) ?></div>
                    </div>
                </div>

                <?php if (!empty($trajet['description'])): ?>
                <div class="detail">
                    <i class="fas fa-info-circle"></i>
                    <div>
                        <label>Description</label>
                        <p style="margin-top: 5px;"><?= nl2br(htmlspecialchars($trajet['description'])) ?></p>
                    </div>
                </div>
                <?php endif; ?>
            </div>

            <!-- Actions -->
            <div class="actions-section">
                <?php if ($trajet_passed): ?>
                    <div class="message warning">
                        <i class="fas fa-exclamation-circle"></i> Ce trajet est déjà passé
                    </div>
                <?php elseif ($places_disponibles > 0): ?>
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <?php if ($already_reserved): ?>
                            <div class="message success">
                                <i class="fas fa-check-circle"></i> Vous avez déjà réservé ce trajet
                                <a href="mes-reservations.php" class="btn-secondary" style="margin-left: 10px;">Voir mes réservations</a>
                            </div>
                        <?php elseif ($_SESSION['user_id'] != $trajet['driver_id']): ?>
                            <?php if ($is_student): ?>
                                <a href="reserver.php?trajet_id=<?= $trajet_id ?>" class="btn-primary">
                                    <i class="fas fa-ticket-alt"></i> Réserver ce trajet
                                </a>
                            <?php else: ?>
                                <div class="message info">
                                    <i class="fas fa-info-circle"></i> Vous devez être inscrit comme étudiant pour réserver
                                    <a href="profile.php" class="btn-secondary" style="margin-left: 10px;">Compléter mon profil</a>
                                </div>
                            <?php endif; ?>
                        <?php else: ?>
                            <div class="message info">
                                <i class="fas fa-info-circle"></i> Vous êtes le conducteur de ce trajet
                                <a href="edit-trip.php?id=<?= $trajet_id ?>" class="btn-secondary" style="margin-left: 10px;">Modifier</a>
                            </div>
                        <?php endif; ?>
                    <?php else: ?>
                        <a href="login.php?redirect=trajet&id=<?= $trajet_id ?>" class="btn-primary">
                            <i class="fas fa-sign-in-alt"></i> Connectez-vous pour réserver
                        </a>
                    <?php endif; ?>
                <?php else: ?>
                    <div class="message warning">
                        <i class="fas fa-exclamation-circle"></i> Ce trajet est complet
                        <a href="search.php" class="btn-secondary" style="margin-left: 10px;">Chercher un autre trajet</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>
    </div>
</body>
</html>