<?php
session_start();
require_once 'includes/db.php';

// Redirection si déjà connecté
if (isset($_SESSION['user_id'])) {
    header("Location: profil.php");
    exit();
}

$error_message = '';
$success_message = '';

// Traitement de la connexion
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Protection CSRF
    if (!isset($_POST['csrf_token']) || $_POST['csrf_token'] !== $_SESSION['csrf_token']) {
        $error_message = "Erreur de validation du formulaire. Veuillez réessayer.";
    } else {
        $email = filter_var(trim($_POST['email']), FILTER_SANITIZE_EMAIL);
        $mot_de_passe = $_POST['mot_de_passe'];
        $remember_me = isset($_POST['remember']) ? true : false;

        // Vérification du format de l'email
        if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $error_message = "Format d'email invalide.";
        } else {
            // Recherche de l'utilisateur
            $stmt = $conn->prepare("SELECT id, nom, prenom, email, mot_de_passe, role FROM users WHERE email = ?");
            $stmt->bind_param("s", $email);
            $stmt->execute();
            $result = $stmt->get_result();
            $user = $result->fetch_assoc();
            $stmt->close();

            if ($user && password_verify($mot_de_passe, $user['mot_de_passe'])) {
                // Connexion immédiate sans vérification de l'état du compte
                session_regenerate_id(true);
                
                // Enregistrement des données de session
                $_SESSION['user_id'] = $user['id'];
                $_SESSION['nom'] = $user['nom'];
                $_SESSION['prenom'] = $user['prenom'];
                $_SESSION['role'] = $user['role'];
                $_SESSION['last_activity'] = time();
                
                // Gestion du "Se souvenir de moi" - Version simplifiée
                if ($remember_me) {
                    // Crée un token simple (à améliorer pour la production)
                    $token = bin2hex(random_bytes(32));
                    $expiry = time() + 30 * 24 * 60 * 60; // 30 jours
                    
                    // Stocke les informations dans un cookie
                    setcookie(
                        'remember_user',
                        $user['id'] . ':' . $token,
                        $expiry,
                        '/',
                        '',
                        true,  // Cookie sécurisé (uniquement HTTPS)
                        true   // Cookie HttpOnly
                    );
                    
                    // Met à jour la base de données avec le token (dans la table users existante)
                    $update_stmt = $conn->prepare("UPDATE users SET remember_token = ? WHERE id = ?");
                    $update_stmt->bind_param("si", $token, $user['id']);
                    $update_stmt->execute();
                    $update_stmt->close();
                }
                
                // Redirection vers le profil
                header("Location: profil.php");
                exit();
            } else {
                // Message générique pour ne pas indiquer si l'email ou le mot de passe est incorrect
                $error_message = "Identifiants incorrects.";
                // Délai pour contrer les attaques par force brute
                sleep(1);
            }
        }
    }
}

// Génération d'un nouveau token CSRF pour chaque chargement de la page
$_SESSION['csrf_token'] = bin2hex(random_bytes(32));
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Connectez-vous à votre compte EtudGo pour accéder à vos trajets et covoiturages étudiants">
    <title>Connexion - EtudGo</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/login.css">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/lucide/0.263.1/lucide.min.js" defer></script>
    <link rel="shortcut icon" href="assets/img/favicon.ico" type="image/x-icon">
</head>
<body>

<header>
    <div class="header-container">
        <a href="index.php" class="header-brand">
            <i data-lucide="car"></i>
            <span>EtudGo</span>
        </a>
        <nav class="header-nav">
            <ul>
                <li><a href="register.php" class="btn-register"><i data-lucide="user-plus"></i> Inscription</a></li>
                <li><a href="index.php" class="btn-text"><i data-lucide="home"></i> Accueil</a></li>
            </ul>
        </nav>
        <button id="menu-toggle" class="mobile-menu-button" aria-label="Menu">
            <i data-lucide="menu"></i>
        </button>
    </div>
</header>

<main class="auth-container">
    <div class="auth-card">
        <div class="auth-header">
            <h1>Connexion</h1>
            <p>Accédez à votre compte EtudGo</p>
        </div>

        <?php if (!empty($error_message)): ?>
            <div class="alert alert-danger" role="alert">
                <i data-lucide="alert-circle"></i>
                <span><?php echo htmlspecialchars($error_message); ?></span>
            </div>
        <?php endif; ?>

        <?php if (!empty($success_message)): ?>
            <div class="alert alert-success" role="alert">
                <i data-lucide="check-circle"></i>
                <span><?php echo htmlspecialchars($success_message); ?></span>
            </div>
        <?php endif; ?>

        <form method="post" class="auth-form" novalidate>
            <input type="hidden" name="csrf_token" value="<?php echo $_SESSION['csrf_token']; ?>">
            
            <div class="form-group">
                <label for="email">Adresse email</label>
                <div class="input-with-icon">
                    <i data-lucide="mail"></i>
                    <input type="email" id="email" name="email" placeholder="Votre adresse email" 
                           value="<?php echo isset($_POST['email']) ? htmlspecialchars($_POST['email']) : ''; ?>" 
                           required autocomplete="email">
                </div>
            </div>

            <div class="form-group">
                <label for="mot_de_passe">Mot de passe</label>
                <div class="input-with-icon password-field">
                    <i data-lucide="lock"></i>
                    <input type="password" id="mot_de_passe" name="mot_de_passe" placeholder="Votre mot de passe" 
                           required autocomplete="current-password">
                    <button type="button" class="toggle-password" aria-label="Afficher/Masquer le mot de passe">
                        <i data-lucide="eye"></i>
                    </button>
                </div>
            </div>

            <div class="form-options">
                <div class="remember-me">
                    <input type="checkbox" id="remember" name="remember">
                    <label for="remember">Se souvenir de moi</label>
                </div>
                <a href="forgot-password.php" class="forgot-password">Mot de passe oublié ?</a>
            </div>

            <button type="submit" class="btn btn-primary btn-block">
                <i data-lucide="log-in"></i>
                Se connecter
            </button>
            
            <div class="social-login">
                <p>Ou connectez-vous avec</p>
                <div class="social-buttons">
                    <a href="auth/google.php" class="btn btn-social btn-google">
                        <img src="assets/img/icons/google.svg" alt="Google">
                        Google
                    </a>
                    <a href="auth/microsoft.php" class="btn btn-social btn-microsoft">
                        <img src="assets/img/icons/microsoft.svg" alt="Microsoft">
                        Microsoft
                    </a>
                </div>
            </div>
        </form>

        <div class="auth-footer">
            <p>Pas encore inscrit ? <a href="register.php">Créer un compte</a></p>
        </div>
    </div>
</main>

<footer>
    <div class="container">
        <div class="footer-content">
            <div class="footer-brand">
                <a href="index.php" class="footer-logo">
                    <i data-lucide="car"></i>
                    <span>EtudGo</span>
                </a>
                <p>La solution de covoiturage pensée pour les étudiants</p>
            </div>
            <div class="footer-links">
                <div class="footer-section">
                    <h3>Aide</h3>
                    <ul>
                        <li><a href="faq.php">FAQ</a></li>
                        <li><a href="contact.php">Contact</a></li>
                        <li><a href="support.php">Support</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h3>Informations</h3>
                    <ul>
                        <li><a href="about.php">À propos</a></li>
                        <li><a href="terms.php">Conditions d'utilisation</a></li>
                        <li><a href="privacy.php">Politique de confidentialité</a></li>
                    </ul>
                </div>
                <div class="footer-section">
                    <h3>Suivez-nous</h3>
                    <div class="social-links">
                        <a href="#" aria-label="Facebook"><i data-lucide="facebook"></i></a>
                        <a href="#" aria-label="Twitter"><i data-lucide="twitter"></i></a>
                        <a href="#" aria-label="Instagram"><i data-lucide="instagram"></i></a>
                        <a href="#" aria-label="LinkedIn"><i data-lucide="linkedin"></i></a>
                    </div>
                </div>
            </div>
        </div>
        <div class="footer-bottom">
            <p>&copy; <?= date('Y'); ?> EtudGo. Tous droits réservés.</p>
        </div>
    </div>
</footer>

<script>
document.addEventListener("DOMContentLoaded", function() {
    // Initialisation des icônes Lucide
    lucide.createIcons();
    
    // Afficher/Masquer le mot de passe
    const togglePassword = document.querySelector('.toggle-password');
    const passwordInput = document.querySelector('#mot_de_passe');
    
    if (togglePassword && passwordInput) {
        togglePassword.addEventListener('click', function() {
            const type = passwordInput.getAttribute('type') === 'password' ? 'text' : 'password';
            passwordInput.setAttribute('type', type);
            
            // Changer l'icône
            const icon = this.querySelector('i');
            if (type === 'password') {
                icon.setAttribute('name', 'eye');
            } else {
                icon.setAttribute('name', 'eye-off');
            }
            lucide.createIcons();
        });
    }
    
    // Menu mobile
    const menuToggle = document.getElementById('menu-toggle');
    const headerNav = document.querySelector('.header-nav');
    
    if (menuToggle && headerNav) {
        menuToggle.addEventListener('click', function() {
            headerNav.classList.toggle('active');
            const icon = this.querySelector('i');
            const isExpanded = headerNav.classList.contains('active');
            this.setAttribute('aria-expanded', isExpanded);
            icon.setAttribute('name', isExpanded ? 'x' : 'menu');
            lucide.createIcons();
        });
    }
    
    // Validation de formulaire côté client
    const form = document.querySelector('.auth-form');
    
    if (form) {
        form.addEventListener('submit', function(event) {
            let isValid = true;
            const email = document.getElementById('email');
            const password = document.getElementById('mot_de_passe');
            
            // Validation email
            if (email && !isValidEmail(email.value)) {
                showError(email, "Veuillez entrer une adresse email valide");
                isValid = false;
            } else if (email) {
                removeError(email);
            }
            
            // Validation mot de passe
            if (password && password.value.trim() === '') {
                showError(password, "Le mot de passe est requis");
                isValid = false;
            } else if (password) {
                removeError(password);
            }
            
            if (!isValid) {
                event.preventDefault();
            }
        });
    }
    
    function isValidEmail(email) {
        const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return re.test(email);
    }
    
    function showError(input, message) {
        const formGroup = input.closest('.form-group');
        let errorElement = formGroup.querySelector('.error-message');
        
        if (!errorElement) {
            errorElement = document.createElement('div');
            errorElement.className = 'error-message';
            formGroup.appendChild(errorElement);
        }
        
        errorElement.textContent = message;
        input.classList.add('input-error');
    }
    
    function removeError(input) {
        const formGroup = input.closest('.form-group');
        const errorElement = formGroup.querySelector('.error-message');
        
        if (errorElement) {
            formGroup.removeChild(errorElement);
        }
        
        input.classList.remove('input-error');
    }
});
</script>
</body>
</html>